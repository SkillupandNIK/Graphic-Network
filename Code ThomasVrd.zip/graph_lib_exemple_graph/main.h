#include "graph.h"

int draw_bouton_image(BITMAP *buffer, int posx, int posy, int pos2x, int pos2y, int color1, int color2, int profondeur, char* nom_image);
int draw_bouton_texte(BITMAP *buffer, int posx, int posy, int pos2x, int pos2y, int color1, int color2, int profondeur, char* texte);
int GestionGraphe(Graph& g, std::string nom_graphe);

